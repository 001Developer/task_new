<?php
@session_start();
include("../../../common/app_function.php");
include("../../../common/config.php");
include("../../../common/diffrence.php");
include_once '../../../common/ckeditor/ckeditor.php';
if($_SESSION[username]=="")
{
	displayerror("Login Error.","","For security of your account,we have expired your session.<br>&nbsp;Please login to your account again.", "Login,../../index.php", 0);
	exit();
}
$id = $_REQUEST[id];
$mode = $_REQUEST[mode];
$query=sprintf("select * from ".$tblpref."blog where blog_id='%d'", $id); 
if(!($result=mysql_query($query))){ echo $query.mysql_error(); exit;}
$row_add=mysql_fetch_array($result);

admin_header('../../../','Blog Management',$tblpref,$db,$sitepath,$siteurl,$path1,$ckpath,$row_admin);
?>
<script type="text/javascript" src="../../../common/ckeditor/ckeditor.js"></script>
<!--body start -->
<div class="adminbody">
<div class="flt"><a href="../../home.php"><img src="../../../images/dashboard.png" alt="Home" title="Home"/></a></div>
<div class="frt" style="padding-right:5px;"><a href="index.php"><img src="../../../images/back32.png" alt="Back" title="Back" /></a></div>
<div class="gap"></div>
<?
$flag = $_REQUEST[flag];
if($flag=="exist"){?>
<p align="center" class="error">Record is already exist.</p>
<? } 	 
if($flag=="filesize"){?>
<p align="center" class="error">File size should not be more than 2MB.</p>
<? } 
if($flag=="type"){?>
<p align="center" class="error">File should be of Image type.</p>
<? } ?>		 

<div class="box">
    <div class="hdr">
	<? if($id!=""){?><h1 class="ico-edit">Edit</h1><?}else{?><h1 class="ico-addnew">Add New</h1><?}?>
	<div class="rtheading">
        <h1 class="ico"><img src="icon/icon.png" alt="">Blog Management</h1>
    </div>
    </div> 
	
      
    <div class="padtb">
     <form name="frmcmsadd" method="POST" onsubmit="return blog();" action="submit.php" enctype="multipart/form-data">
     <table width="100%" border="0" cellspacing="0" cellpadding="0">
	 <tr class="even">
		<td>Magazine<font color="#ff0000">* </font> :     </td>
     </tr>
     <tr>
		<td>
			<select name="magazine" id="magazine" class="smlslct" onchange="dropdown(this.id);">
				<option value="" >Please Select</option>
				<?php 
				$query1=sprintf("select * from ".$tblpref."magazine ORDER BY mag_id DESC"); 
				if(!($result1=mysql_query($query1))){ echo $query1.mysql_error(); exit;}
				while($row1=mysql_fetch_array($result1))
				{?>
				<option value="<?=$row1[mag_id]?>" <?if($row1[mag_id]==$row_add[blog_mag_id]){?>selected<?}?>><?php  echo stripslashes($row1[mag_title])?></option>
				<?php }?>
			</select>
		</td>
     </tr>
	  <tr class="even">
		<td>Category<font color="#ff0000">* </font> :     </td>
     </tr>
     <tr>
		<td>
			<select name="category" id="category" class="smlslct" onchange="dropdown(this.id);">
				<option value="" >Please Select</option>
				<?php 
				$query2=sprintf("select * from ".$tblpref."category WHERE cat_type='blog' ORDER BY cat_id DESC"); 
				if(!($result2=mysql_query($query2))){ echo $query2.mysql_error(); exit;}
				while($row2=mysql_fetch_array($result2))
				{?>
				<option value="<?=$row2[cat_id]?>" <?if($row2[cat_id]==$row_add[blog_cat_id]){?>selected<?}?>><?php  echo stripslashes($row2[cat_title])?></option>
				<?php }?>
			</select>
		</td>
     </tr>
     <tr class="even">
		<td>Title<font color="#ff0000">* </font> :     </td>
     </tr>
     <tr>
		<td>
			<input type="text" name="title" id="title" value="<?=stripslashes($row_add[blog_title])?>" onBlur="alphanumvalid(this.id);" class="smlinput" autocomplete="off"/>
		</td>
     </tr>
	 
	 <?php if($row_add[blog_udate]!=""){ ?>
	 <tr class="even">
       <td>Last Updated Date :</td>
     </tr>
     <tr>
       <td><input type="text" name="udate" id="udate" value="<?php echo dateformate($row_add[blog_udate]);?>" readonly class="smlinput" autocomplete="off"/></td>
     </tr>
	<?php }?>
	 
	 <tr class="even">
       <td>Description :</td>
     </tr>
     <tr>
       <td align="left" style="padding:5px 15px;">
			<?php
			$ckeditor = new CKEditor();
			$ckeditor->basePath = '/ckeditor/';
			$ckeditor->config['filebrowserBrowseUrl'] = $ckpath.'/ckfinder/ckfinder.html';
			$ckeditor->config['filebrowserImageBrowseUrl'] = $ckpath.'/ckfinder/ckfinder.html?type=Images';
			$ckeditor->config['filebrowserFlashBrowseUrl'] = $ckpath.'/ckfinder/ckfinder.html?type=Flash';
			$ckeditor->config['filebrowserUploadUrl'] = $ckpath.'/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files';
			$ckeditor->config['filebrowserImageUploadUrl'] = $ckpath.'/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images';
			$ckeditor->config['filebrowserFlashUploadUrl'] = $ckpath.'/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash';				$ckeditor->editor('linkcontect',stripslashes($row_add[blog_desc]));
			?>
	   </td>
     </tr>
	 
     
	 <tr class="even">
		<td> Main Image : </td>
     </tr>
     <tr>
		<td>
			<input type="file" name="mimage" id="mimage" value="<?=stripslashes($row_add[blog_mimage])?>" class="smlinput" />
			<?if($row_add[blog_mimage] !=""){?>					
				<a href="#"  ONCLICK="open('../../../<?=$uploadpath.$row_add[blog_mimage]?>','barcode','scrollbars=1,toolbar=0,location=0,resizable=0,width=500,height=520')"> View Main Image</a> 
			<?}?>
			<br>
			<label class="error">File size should not be more than 2MB</label>
		</td>
     </tr>
	 <tr class="even">
		<td> Image2 : </td>
     </tr>
     <tr>
		<td>
			<input type="file" name="image2" id="image2" value="<?=stripslashes($row_add[blog_image2])?>" class="smlinput" />
			<?if($row_add[blog_image2] !=""){?>					
				<a href="#"  ONCLICK="open('../../../<?=$uploadpath.$row_add[blog_image2]?>','barcode','scrollbars=1,toolbar=0,location=0,resizable=0,width=500,height=520')"> View Image2</a> 
			<?}?>
			<br>
			<label class="error">File size should not be more than 2MB</label>
		</td>
     </tr>
	 <tr class="even">
		<td> Image3 : </td>
     </tr>
     <tr>
		<td>
			<input type="file" name="image3" id="image3" value="<?=stripslashes($row_add[blog_image3])?>" class="smlinput" />
			<?if($row_add[blog_image3] !=""){?>					
				<a href="#"  ONCLICK="open('../../../<?=$uploadpath.$row_add[blog_image3]?>','barcode','scrollbars=1,toolbar=0,location=0,resizable=0,width=500,height=520')"> View Image3</a> 
			<?}?>
			<br>
			<label class="error">File size should not be more than 2MB</label>
		</td>
     </tr>
	 <tr class="even">
		<td> Image4 : </td>
     </tr>
     <tr>
		<td>
			<input type="file" name="image4" id="image4" value="<?=stripslashes($row_add[blog_image4])?>" class="smlinput" />
			<?if($row_add[blog_image4] !=""){?>					
				<a href="#"  ONCLICK="open('../../../<?=$uploadpath.$row_add[blog_image4]?>','barcode','scrollbars=1,toolbar=0,location=0,resizable=0,width=500,height=520')"> View Image4</a> 
			<?}?>
			<br>
			<label class="error">File size should not be more than 2MB</label>
		</td>
     </tr>
	 
	 <tr class="even">
		<td>&nbsp;</td>
	 </tr>     
     <tr >
     	<td>
        <input type="submit" class="button" value="Submit" name="submit">
		<?if($id==""){?>
		<input type="hidden" value="add" name="mode" >
		<?}else{?>
		<input type="hidden" value="<?=$id?>" name="id" >
		<?}?>
        </td>
     </tr>   
     </table>
     
     </form>   
     
    <div class="clear"></div>
    </div>
    <div class="clear"></div>
</div>
</div>
<?admin_footer()?>
