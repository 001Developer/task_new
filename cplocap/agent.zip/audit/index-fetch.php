<div class="form-group">
<label class="control-label col-sm-4">User :</label>
			<div class="col-sm-6">     
		<?php
		require("../../common/config.php");
				$atype = $_POST[atype];
				if($atype=="all")
				{
					$query = sprintf("SELECT * FROM " . $tblpref . "admin ORDER BY admin_id DESC");
				}
				if($atype=="superadmin")
				{
					$query = sprintf("SELECT * FROM " . $tblpref . "admin WHERE user_type='superadmin'  ORDER BY admin_id DESC");
				}
				if($atype=="subadmin")
				{
					$query = sprintf("SELECT * FROM " . $tblpref . "admin WHERE user_type='subadmin'  ORDER BY admin_id DESC");
				}
				if($atype=="subeditor")
				{
					$query = sprintf("SELECT * FROM " . $tblpref . "admin WHERE user_type='subeditor'  ORDER BY admin_id DESC");
				}
				if($atype=="reporter")
				{
					$query = sprintf("SELECT * FROM " . $tblpref . "admin WHERE user_type='reporter'  ORDER BY admin_id DESC");
				}
				if(!($result = mysqli_query($connection,$query))) { echo "Query - " . $query . "<br />Error - " . mysqli_error(); exit; };
?>
	
		
			<select name="admins" id="admins" class="form-control" onchange="showchk(this.value);">
			<option value="">Please Select</option>
						
			<?php 
				
				while($row = mysqli_fetch_array($result)) :
			?>
				<option value="<?php echo $row['admin_id'];?>"><?php echo stripslashes($row['admin_name']);?></option>
			
			<?php 				
				endwhile;?>
			</select>
		</div>
	</div>
</div>