<?php
@session_start();
include("../../../common/app_function.php");
include("../../../common/config.php");
if($_SESSION[username]=="")
{
	displayerror("Login Error.","","For security of your account,we have expired your session.<br>&nbsp;Please login to your account again.", "Login,../../index.php", 0);
	exit();
}

if($_FILES["mimage"]["name"]!="")
{
	$type = $_FILES["mimage"]["type"];
	$type = explode("/",$type);
	if($type[0]!='image')
	{
		header("Location:add.php?flag=type&id=$_REQUEST[id]&mode=$mode");
		exit;
	}
	if($_FILES["mimage"]["size"]>"2097152")
	{
		header("Location:add.php?flag=filesize&id=$_REQUEST[id]&mode=$mode");
		exit;
	}
}

if($_FILES["image2"]["name"]!="")
{
	$type = $_FILES["image2"]["type"];
	$type = explode("/",$type);
	if($type[0]!='image')
	{
		header("Location:add.php?flag=type&id=$_REQUEST[id]&mode=$mode");
		exit;
	}
	if($_FILES["image2"]["size"]>"2097152")
	{
		header("Location:add.php?flag=filesize&id=$_REQUEST[id]&mode=$mode");
		exit;
	}
}

if($_FILES["image3"]["name"]!="")
{
	$type = $_FILES["image3"]["type"];
	$type = explode("/",$type);
	if($type[0]!='image')
	{
		header("Location:add.php?flag=type&id=$_REQUEST[id]&mode=$mode");
		exit;
	}
	if($_FILES["image3"]["size"]>"2097152")
	{
		header("Location:add.php?flag=filesize&id=$_REQUEST[id]&mode=$mode");
		exit;
	}
}

if($_FILES["image4"]["name"]!="")
{
	$type = $_FILES["image4"]["type"];
	$type = explode("/",$type);
	if($type[0]!='image')
	{
		header("Location:add.php?flag=type&id=$_REQUEST[id]&mode=$mode");
		exit;
	}
	if($_FILES["image4"]["size"]>"2097152")
	{
		header("Location:add.php?flag=filesize&id=$_REQUEST[id]&mode=$mode");
		exit;
	}
}



$magazine=$_POST[magazine];
$category=$_POST[category];
$title=addslashes($_POST[title]);
$description=addslashes($_POST[linkcontect]);


$mode = $_REQUEST[mode];


if($mode=="del")
{
	$id= $_GET[id];	

	$qchk=sprintf("SELECT * FROM ".$tblpref."blog WHERE blog_id='%d'", $id);
	if(!($resqchk=mysql_query($qchk))){ echo "FOR QUERY: $query<BR>".mysql_error(); exit;}
	$row=mysql_fetch_array($resqchk);
	$mainimg = $row[blog_mimage];
	$image2 = $row[blog_image2];
	$image3 = $row[blog_image3];
	$image4 = $row[blog_image4];

	if($mainimg!="")
	{
		@unlink("../../../".$uploadpath.$mainimg);
	}
	if($image2!="")
	{
		@unlink("../../../".$uploadpath.$image2);
	}
	if($image3!="")
	{
		@unlink("../../../".$uploadpath.$image3);
	}
	if($image4!="")
	{
		@unlink("../../../".$uploadpath.$image4);
	}

	$title=$row[blog_title];
	log_entry("Blog",$title,"deleted", $tblpref,  $db, $row_admin[admin_id],$ip);

	$query=sprintf("Delete from ".$tblpref."blog where blog_id ='%d'", $id);
	if(!($result=mysql_query($query))){echo mysql_error($query); exit;}

	header("Location:index.php?flag=del");
	exit;
}
$id = $_POST[id];
if($id=="")
{
	$qchk=sprintf("SELECT * FROM ".$tblpref."blog WHERE blog_mag_id='%d' AND blog_cat_id='%d' AND blog_title='%s'", $magazine, $category, $title);
	if(!($resqchk=mysql_query($qchk))){ echo "FOR QUERY: $query<BR>".mysql_error(); exit;}
	$rowcount=mysql_num_rows($resqchk);
	if($rowcount>0)
	{
		header("location:add.php?flag=exist&mode=add");
	    exit;
	}
	else
	{
		$qadd=sprintf("INSERT INTO ".$tblpref."blog SET blog_mag_id='%d', blog_cat_id='%d', blog_title='%s', blog_udate=CURDATE(), blog_utime=CURTIME(), blog_desc='%s'", $magazine, $category, $title, $description);
		if(!($res=mysql_query($qadd))){echo $qadd.mysql_error(); exit;}
		$id = mysql_insert_id();

		log_entry("Blog",$title,"added", $tblpref,  $db, $row_admin[admin_id],$ip);
		
		$cudate=date("d-m-Y");

		if($_FILES["mimage"]["name"]!="") 
		{
			 $fileload = $_FILES["mimage"]["name"];
			 $file_ext = explode(".",$fileload);
			 
			 //<date of blog>-<Magazine Name>-<News Name>-<main or image number>.<ext>
			 $mag_name = mag_name($magazine);
			 $myattach=$cudate."_".$mag_name."_".$heading."_image_main.".$file_ext[1];
			 $destpath="../../../".$uploadpath.$myattach;
			 
			 copy($_FILES["mimage"]["tmp_name"],$destpath) or die("Unable to upload Image");
		
			 $update=sprintf("UPDATE ".$tblpref."blog SET blog_mimage ='%s' WHERE blog_id ='%d'", $myattach, $id); 
			 if(!($result = mysql_query($update))){echo $update.mysql_error();exit;}
		}
		if($_FILES["image2"]["name"]!="") 
		{
			 $fileload = $_FILES["image2"]["name"];
			 $file_ext = explode(".",$fileload);
		
			 $mag_name = mag_name($magazine);
			 $myattach=$cudate."_".$mag_name."_".$heading."_image_2.".$file_ext[1];
			 $destpath="../../../".$uploadpath.$myattach;
			 
			 copy($_FILES["image2"]["tmp_name"],$destpath) or die("Unable to upload Image");
		
			 $updatecategory=sprintf("UPDATE ".$tblpref."blog SET blog_image2 ='%s' WHERE blog_id ='%d'", $myattach, $id); 
			 if(!($result = mysql_query($updatecategory))){echo $updatecategory.mysql_error();exit;}
		}
		if($_FILES["image3"]["name"]!="") 
		{
			 $fileload = $_FILES["image3"]["name"];
			 $file_ext = explode(".",$fileload);
			 
			 $mag_name = mag_name($magazine);
			 $myattach=$cudate."_".$mag_name."_".$heading."_image_3.".$file_ext[1];
			 $destpath="../../../".$uploadpath.$myattach;
			 
			 copy($_FILES["image3"]["tmp_name"],$destpath) or die("Unable to upload Image");
		
			 $updatecategory=sprintf("UPDATE ".$tblpref."blog SET blog_image3 ='%s' WHERE blog_id ='%d'", $myattach, $id); 
			 if(!($result = mysql_query($updatecategory))){echo $updatecategory.mysql_error();exit;}
		}
		if($_FILES["image4"]["name"]!="") 
		{
			 $fileload = $_FILES["image4"]["name"];
			 $file_ext = explode(".",$fileload);
			 
			 $mag_name = mag_name($magazine);
			 $myattach=$cudate."_".$mag_name."_".$heading."_image_4.".$file_ext[1];
			 $destpath="../../../".$uploadpath.$myattach;
			 
			 copy($_FILES["image4"]["tmp_name"],$destpath) or die("Unable to upload Image");
		
			 $updatecategory=sprintf("UPDATE ".$tblpref."blog SET blog_image4 ='%s' WHERE blog_id ='%d'", $myattach, $id); 
			 if(!($result = mysql_query($updatecategory))){echo $updatecategory.mysql_error();exit;}
		}
		header("Location:index.php?flag=add");
		exit;
	}
}

if($id!="")
{		
	$qadd=sprintf("UPDATE ".$tblpref."blog SET blog_mag_id='%d', blog_cat_id='%d', blog_title='%s', blog_udate=CURDATE(), blog_utime=CURTIME(), blog_desc='%s' WHERE blog_id='%d'",$magazine, $category, $title, $description, $id);
	if(!($res=mysql_query($qadd))){echo $qadd.mysql_error(); exit;}

	log_entry("Blog",$title,"edited", $tblpref,  $db, $row_admin[admin_id],$ip);

	$cudate=date("d-m-Y");

	if($_FILES["mimage"]["name"]!="") 
	{
		 $fileload = $_FILES["mimage"]["name"];
		 $file_ext = explode(".",$fileload);
		 
		 //<date of blog>-<Magazine Name>-<News Name>-<main or image number>.<ext>
		 $mag_name = mag_name($magazine);
		 $myattach=$cudate."_".$mag_name."_".$heading."_image_main.".$file_ext[1];
		 $destpath="../../../".$uploadpath.$myattach;
		 
		 copy($_FILES["mimage"]["tmp_name"],$destpath) or die("Unable to upload Image");
	
		 $update=sprintf("UPDATE ".$tblpref."blog SET blog_mimage ='%s' WHERE blog_id ='%d'", $myattach, $id); 
		 if(!($result = mysql_query($update))){echo $update.mysql_error();exit;}
	}
	if($_FILES["image2"]["name"]!="") 
	{
		 $fileload = $_FILES["image2"]["name"];
		 $file_ext = explode(".",$fileload);
	
		 $mag_name = mag_name($magazine);
		 $myattach=$cudate."_".$mag_name."_".$heading."_image_2.".$file_ext[1];
		 $destpath="../../../".$uploadpath.$myattach;
		 
		 copy($_FILES["image2"]["tmp_name"],$destpath) or die("Unable to upload Image");
	
		 $updatecategory=sprintf("UPDATE ".$tblpref."blog SET blog_image2 ='%s' WHERE blog_id ='%d'", $myattach, $id); 
		 if(!($result = mysql_query($updatecategory))){echo $updatecategory.mysql_error();exit;}
	}
	if($_FILES["image3"]["name"]!="") 
	{
		 $fileload = $_FILES["image3"]["name"];
		 $file_ext = explode(".",$fileload);
		 
		 $mag_name = mag_name($magazine);
		 $myattach=$cudate."_".$mag_name."_".$heading."_image_3.".$file_ext[1];
		 $destpath="../../../".$uploadpath.$myattach;
		 
		 copy($_FILES["image3"]["tmp_name"],$destpath) or die("Unable to upload Image");
	
		 $updatecategory=sprintf("UPDATE ".$tblpref."blog SET blog_image3 ='%s' WHERE blog_id ='%d'", $myattach, $id); 
		 if(!($result = mysql_query($updatecategory))){echo $updatecategory.mysql_error();exit;}
	}
	if($_FILES["image4"]["name"]!="") 
	{
		 $fileload = $_FILES["image4"]["name"];
		 $file_ext = explode(".",$fileload);
		 
		 $mag_name = mag_name($magazine);
		 $myattach=$cudate."_".$mag_name."_".$heading."_image_4.".$file_ext[1];
		 $destpath="../../../".$uploadpath.$myattach;
		 
		 copy($_FILES["image4"]["tmp_name"],$destpath) or die("Unable to upload Image");
	
		 $updatecategory=sprintf("UPDATE ".$tblpref."blog SET blog_image4 ='%s' WHERE blog_id ='%d'", $myattach, $id); 
		 if(!($result = mysql_query($updatecategory))){echo $updatecategory.mysql_error();exit;}
	}
	header("Location:index.php?flag=edit");
	exit;
}	
?>