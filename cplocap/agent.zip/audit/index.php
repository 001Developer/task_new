<?php
@session_start();
include("../../common/app_function.php");
include("../../common/config.php");
if($_SESSION[username]=="")
{
	displayerror("Login Error.","","For security of your account,we have expired your session.<br>&nbsp;Please login to your account again.", "Login,../index.php", 0);
	exit();
}

$cur_moduel = basename(__DIR__);

$mod_tit = ucwords(check_moduel_name($cur_moduel,$tblpref,$db,$sitepath,$siteurl,$path1,$ckpath,$row_admin));

$flag=$_GET[flag];
$atype = $_GET[atype];
admin_header('../../',$mod_tit." List",$tblpref,$db,$sitepath,$siteurl,$path1,$ckpath,$row_admin);
admin_nav('../../',$mod_tit." List",$tblpref,$db,$sitepath,$siteurl,$path1,$ckpath,$row_admin,$connection, $cur_moduel);

?>


<!--body start -->
<div class="col-md-9 col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main" ng-app="myApp" ng-controller="customersCrtl">
 
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="<?php echo $path4; ?>home.php"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
		<li class="active"><?php echo $mod_tit; ?></li>
			</ol>
		</div><!--/.row-->

		<div class="row">

        <div class="col-md-offset-2 col-md-8">
			<div class = "panel panel-primary">
				<div class = "panel-heading" style="height: 40px;">
					<h3 class = "panel-title"><span class="glyphicon glyphicon-search"></span>Search</h3>
				</div>

			<div class="panel-body">

				<form  class="form-horizontal">
					<div class="form-group">
						<label class="control-label col-sm-4">User Type :</label>
						<div class="col-sm-6">
						  <select name="atype" id="atype" class="form-control" onchange="showadmins(this.value);">
								<option value="" >Please Select</option>
								<option value="all" <?php if($atype=="all"){echo "Selected";}?>>All</option> 
								<option value="superadmin" <?php if($atype=="superadmin"){echo "Selected";}?>>Super Administrator</option> 
								<option value="subadmin" <?php if($atype=="superadmin"){echo "Selected";}?>>Sub Admin</option> 
								<!-- <option value="editor" <?php if($atype=="editor"){echo "Selected";}?>>Editor</option> 
								<option value="subeditor" <?php if($atype=="subeditor"){echo "Selected";}?>>Sub Editor</option> 
								<option value="reporter" <?php if($atype=="reporter"){echo "Selected";}?>>Reporter</option>  -->
						  </select>
						</div>
					</div>

					<? if($atype!='') 
					{
						$class = "unhide";
					}
					else
					{ 
						$class = "hide";
					}?>
					<div class="<?=$class?>" id="q1">
					<div class="form-group">
						<label class="control-label col-sm-4">User :</label>
									<div class="col-sm-6">     
										<select name="admins" id="admins" class="form-control" onchange="showchk(this.value);">
											<option value="">Please Select</option>
											<?php 
											if($atype!="")
											{
												if($atype!="all")
												{
													$query = sprintf("SELECT * FROM " . $tblpref . "admin WHERE user_type='$atype' ORDER BY admin_id DESC");
												}
												else
												{
													echo $query = sprintf("SELECT * FROM " . $tblpref . "admin WHERE user_type='superadmin' OR user_type='subadmin' ORDER BY admin_id DESC");
												}
												if(!($result = mysqli_query($connection,$query))) { echo "Query - " . $query . "<br />Error - " . mysqli_error(); exit; };
												while($row = mysqli_fetch_array($result))
												{?>
													<option value="<?php echo $row['admin_id'];?>" <?
													if($row[admin_id]==$txthadmins)
														{
															echo "selected";
														}
														
													?>><?php echo stripslashes($row['admin_name']);?></option>		
										   <?php		
												}
											}?>
										</select>
									</div>
								</div>
					</div>
					<div class="form-group">
						<label class="control-label col-sm-4">Date From :</label>
						<div class="col-sm-6">
							<input type="text" name="datepicker1" id="datepicker1"  align= "text-center"  data-date-format='dd-mm-yyyy' class="form-control datetimepicker" autocomplete="off">
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-sm-4">Date To :</label>
						<div class="col-sm-6">
							<input type="text" name="datepicker2" id="datepicker2" align= "text-center"  data-date-format='dd-mm-yyyy' class="form-control datetimepicker" autocomplete="off">
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-sm-4">&nbsp;</label>
						<div class="col-sm-6">
						    <input type="hidden" name="txthadmins" id="txthadmins" value="<?php echo stripslashes($txthadmins);?>"  />
							<input type="button" ng-click='myFunc()' value="Search" class="btn btn-primary" />
						</div>
					</div>
					</div>
				 </form>
			</div>
		</div>
        
	</div><!--/.row-->
		<?php
		if($flag=="add")
		{ ?>
			<div class="row">
				<div class="col-lg-2">&nbsp;</div>
				<div class="col-lg-8">
					<div class="alert bg-success" role="alert">
					<svg class="glyph stroked checkmark"><use xlink:href="#stroked-checkmark"></use></svg> Record Added Successfully</a>
				</div>
				<div class="col-lg-2"></div>
				</div>
			</div>
		<?php
		}
		if($flag=="edit")
		{ ?>
			<div class="row">
				<div class="col-lg-2">&nbsp;</div>
				<div class="col-lg-8">
					<div class="alert bg-success" role="alert">
					<svg class="glyph stroked checkmark"><use xlink:href="#stroked-checkmark"></use></svg> Record Updated Successfully</a>
				</div>
				<div class="col-lg-2"></div>
				</div>
			</div>
		<?php
		}
		if($flag=="del")
		{ ?>
			<div class="row">
				<div class="col-lg-2">&nbsp;</div>
				<div class="col-lg-8">
					<div class="alert bg-danger" role="alert">
					<svg class="glyph stroked cancel"><use xlink:href="#stroked-cancel"></use></svg> Record Deleted Successfully</a>
				</div>
				<div class="col-lg-2"></div>
				</div>
			</div>
		<?php
		}
	?>
  <div class="row">
		<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading"><i class="fa fa-map-signs fa-2x fa-fw" aria-hidden="true"></i><?php echo $mod_tit;?><div class="pull-right" ng-show="filteredItems > 0">
					<a href="export.php?atype=<?=$_GET[atype]?>&admins=<?=$_GET[admins]?>&datepicker1=<?=$_GET[datepicker1]?>&datepicker2=<?=$_GET[datepicker2]?>"><button type="button" class="btn btn-default btn-sm">
					<span class="glyphicon glyphicon-file"></span> Export 
					</button></a>
                    
				</div>
		</div>
			
		<div class="panel-body">
			<table class="table table-bordered" ng-show="filteredItems > 0">
				<thead>
				<tr>
					<th>Sr. No.</th>
					<th>Date Time</th>
					<th>Admin</th>
					<th>Type</th>
					<th>Module</th>
					<th>Name</th>
					<th>Action</th>
				</tr>
				</thead>
				<tbody>
				
				<tr ng-repeat="data in totalItems = (list | orderBy : predicate :reverse) | startFrom:(currentPage-1)*entryLimit | limitTo:entryLimit">
					<td><b>{{data.count}}</b></td>
					<td>{{data.date}}</td>
					<td>{{data.admin_name}}</td>	
					<td>{{data.admin}}</td>
					<td>{{data.log_admin_module}}</td>
					<td>{{data.log_admin_rec_title}}</td>
					<td>{{data.action}}</td>
				</tr>  
				</tbody>
			</table>
			<div class="col-md-12" ng-show="filteredItems == 0">
				<h4>No Records found.</h4>
			</div>

			<div class="col-md-12" ng-show="filteredItems > 0">
				<div pagination="" page="currentPage" on-select-page="setPage(page)" boundary-links="true" total-items="filteredItems" items-per-page="entryLimit" class="pagination-small" previous-text="&laquo;" next-text="&raquo;">
			</div>
	    </div>
  </div>
</div>
<script src="../../js/angular.min.js"></script> 
<script src="../../js/ui-bootstrap-tpls-0.10.0.min.js"></script> 
<script>
var app = angular.module('myApp', ['ui.bootstrap']);

app.filter('startFrom', function() {
    return function(input, start) {
        if(input) {
            start = +start; //parse to int
            return input.slice(start);
        }
        return [];
    }
});
app.controller('customersCrtl', function ($scope, $http, $timeout, $log) {


	$http.get('fetch.php').success(function(data){
        //alert(data);
		$log.info(data);
		$scope.list = data;
        $scope.currentPage = 1; //current page
        $scope.entryLimit = 10; //max no of items to display in a page
        $scope.filteredItems = $scope.list.length; //Initially for no filter  
        $scope.totalItems = $scope.list.length;
    });
	$scope.myFunc= function(){
	var atype= document.getElementById('atype').value;
	var txthadmins= document.getElementById('txthadmins').value;
	var datepicker1 =document.getElementById('datepicker1').value;
    var datepicker2= document.getElementById('datepicker2').value;
	//var txthadmins = document.getElementsByName("txthadmins");
	
	//alert(val);
    $http.get("fetch.php?atype="+atype+"&txthadmins="+txthadmins+"&datepicker1="+datepicker1+"&datepicker2="+datepicker2).success(function(data){
        //alert(data);
		$scope.list = data;
        $scope.currentPage = 1; //current page
        $scope.entryLimit = 10; //max no of items to display in a page
        $scope.filteredItems = $scope.list.length; //Initially for no filter  
        $scope.totalItems = $scope.list.length;
    });
	};
	
    $scope.setPage = function(pageNo) {
        $scope.currentPage = pageNo;
    };
    $scope.filter = function() {
        $timeout(function() { 
            $scope.filteredItems = $scope.filtered.length;
        }, 10);
    };
    $scope.sort_by = function(predicate) {
        $scope.predicate = predicate;
        $scope.reverse = !$scope.reverse;
    };
	
});

app.controller('dropdown', function ($scope, $http, $timeout) {
	
});
</script>

<?admin_footer();?>

<SCRIPT LANGUAGE="JavaScript">
function showadmins(val)
{
	if(val=="")
	{
		document.getElementById('q1').className="hide";
	}
	if(val!="")
	{
		if(val=="all")
		{
			document.getElementById('txthadmins').value="";
		}
		
		document.getElementById('q1').className="unhide";
		
		$.post("index-fetch.php", { atype: val },
		function(data) {
			$("#q1").fadeOut('slow',function() {
					$("#q1").html(data);
			});
			$("#q1").fadeIn('slow');
		});
		
	}
	
}
function showchk(val)
{
	document.getElementById('txthadmins').value=val;
}
</SCRIPT>
