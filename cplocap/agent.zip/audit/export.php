<?php @session_start();
include("../../common/app_function.php");
include("../../common/config.php");
if($_SESSION[username]=="")
{
	displayerror("Login Error.","","For security of your account,we have expired your session.<br>&nbsp;Please login to your account again.", "Login,../index.php", 0);
	exit();
}

$cur_moduel = basename(__DIR__);
$mod_tit = ucwords(check_moduel_name($cur_moduel,$tblpref,$db,$sitepath,$siteurl,$path1,$ckpath,$row_admin));


$condition2=" ORDER BY log_id DESC";	
$atype = $_GET[atype];
$admins = $_GET[admins];
if($admins!="")
{
	$condition[]=sprintf("log_admin_id='%d'", $admins);
}
if($_GET[datepicker1]!="" && $_GET[datepicker2]=="")
{
	$condition[]=" log_admin_date ='".dateformate($_GET[datepicker1])."'";
}
if($_GET[datepicker1]=="" && $_GET[datepicker2]!="")
{
	$condition[]=" log_admin_date ='".dateformate($_GET[datepicker2])."'";
}
if($_GET[datepicker1]!="" && $_GET[datepicker2]!="")
{
	if($_GET[datepicker1] != $_GET[datepicker2])
	{
		$condition[]=" log_admin_date BETWEEN '".dateformate($_GET[datepicker1])."' AND '".dateformate($_GET[datepicker2])."'";	
	}
	else	
	{
		$condition[]=" log_admin_date ='".dateformate($_GET[datepicker1])."'";	
	}
}
if(is_array($condition))
{
	$condition=" WHERE " . implode(" AND ",$condition);
}

$table_name = $tblpref."log";
$column_set = "*";
$order_by = "log_id";
$page_res = select_multiple_records($connection,$table_name,$column_set,$condition,$order_by,__FILE__,__LINE__);

//count records
$num_export  = count_table_record($connection,$table_name,$condition,__FILE__,__LINE__);

if($num_export > 0)
{
	$filename  = $mod_tit;
	$ext       = 'csv';
	$mime_type = 'application/csv';
	$tabsp='","';
	$start_tabsp='"';
	$end_tabsp='"';

	include("../../common/download-1.php");

	echo $start_tabsp."Date/Time".$tabsp."Admin".$tabsp."Type".$tabsp."Module".$tabsp."Name".$tabsp."Ip".$tabsp."Action".$end_tabsp." \r\n";

	while($row_export=mysqli_fetch_array($page_res))
	{ 
		$table_name_admin = $tblpref."admin";
		$feald_set_admin = "admin_name, user_type";
		$condition_admin = sprintf("admin_id='%d'",$row_export['log_admin_id']);
		$row_log_admn = select_single_record($connection,$table_name_admin,$feald_set_admin,$condition_admin,__FILE__,__LINE__);
		switch(stripslashes($row_log_admn[user_type]))
		{
			case "superadmin":
				$adty= "Super Administrator";
				break;
			case "editor":
				$adty="Editor";
				break;
			case "subeditor":
				$adty="Sub Editor";
				break;
			case "reporter":
				$adty="Reporter";
				break;
		}
		if($row_export[log_admin_action]=="dbanner")
		{
			$act="Changed To Default Banner";
		}
		else
		{
			$act=ucfirst($row_export[log_admin_action]);
		}
		$date=dateformate($row_export[log_admin_date])."/".$row_export[log_admin_time];
		$name=stripslashes($row_log_admn[admin_name]);
		$title=stripslashes($row_export[log_admin_rec_title]);
		$module=stripslashes($row_export[log_admin_module]);
		$ip=$row_export[log_admin_ip];					
		
		echo $start_tabsp."$date".$tabsp."$name".$tabsp."$adty".$tabsp."$module".$tabsp."$title".$tabsp."$ip".$tabsp."$act".$end_tabsp." \r\n";
	}

	@log_entry($mod_tit,$name,"Exported", $tblpref,  $db, $row_admin[admin_id] );
}
else
{
	header("Location:index.php?flag=norcrd&ban_pos=".$ban_pos);
	exit();
}

	
?>