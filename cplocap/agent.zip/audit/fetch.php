<?php
@session_start();
include("../../common/config.php");
include("../../common/app_function.php");

$atype = $_GET[atype];
$txthadmins = $_GET[txthadmins];
if($txthadmins!="")
{
	$condition[]=sprintf("log_admin_id='%d'", $txthadmins);
}
if($_GET[datepicker1]!="" && $_GET[datepicker2]=="")
{
	$condition[]=" log_admin_date ='".dateformate($_GET[datepicker1])."'";
}
if($_GET[datepicker1]=="" && $_GET[datepicker2]!="")
{
	$condition[]=" log_admin_date ='".dateformate($_GET[datepicker2])."'";
}
if($_GET[datepicker1]!="" && $_GET[datepicker2]!="")
{
	if($_GET[datepicker1] != $_GET[datepicker2])
	{
		$condition[]=" log_admin_date BETWEEN '".dateformate($_GET[datepicker1])."' AND '".dateformate($_GET[datepicker2])."'";
	}
	else
	{
		$condition[]=" log_admin_date ='".dateformate($_GET[datepicker1])."'";
	}
}
if(is_array($condition))
{
	$condition=implode(" AND ",$condition);
}
$table_name = $tblpref."log";
$column_set = "*";
$order_by = "log_id DESC";
$page_res = select_multiple_records($connection,$table_name,$column_set,$condition,$order_by,__FILE__,__LINE__);

//count records
$rowCount  = count_table_record($connection,$table_name,$condition,__FILE__,__LINE__);
$count=1;
$arr=array();
if($rowCount>0)
{
	while($row_log=mysqli_fetch_array($page_res))
	{ 
		$arr[id]=$row_log[log_id];
		$arr[count] = $count;
		$arr[date] = @date('d M l Y',@strtotime($row_log[log_admin_date]))." ".@date('h:i a',@strtotime($row_log[log_admin_time]));
		//$arr[date] = dateformate("2016-20-15");

		$table_name_admin = $tblpref."admin";
		$feald_set_admin = "admin_name, user_type";
		$condition_admin = sprintf("admin_id='%d'",$row_log['log_admin_id']);
		$row_log_admn = select_single_record($connection,$table_name_admin,$feald_set_admin,$condition_admin,__FILE__,__LINE__);
		$arr[admin_name] = stripslashes($row_log_admn[admin_name]);
		switch(stripslashes($row_log_admn[user_type]))
		{
			case "superadmin":
				$arr[admin] = "Super Administrator";
				break;
			case "subadmin":
				$arr[admin] = "Subadmin";
				break;
		}
		$arr[log_admin_module] = stripslashes($row_log[log_admin_module]);
		$arr[log_admin_rec_title] = stripslashes($row_log[log_admin_rec_title]);
		if($row_log[log_admin_action]=="dbanner")
		{
			$arr[action] = "Changed To Default Banner";
		}
		else
		{
			$arr[action] = ucfirst($row_log[log_admin_action]);
		}
		$array[] = $arr;
		$count=$count+1;
	} 
	echo json_encode($array);
}
else
{
	echo json_encode($arr);
} ?>